import numpy as np
from scipy.ndimage import sobel
from numpy.linalg import norm

def sam(ms, ps):

    assert ms.ndim == 3 and ms.shape == ps.shape
    dot_sum = np.sum(ms * ps, axis=2)
    norm_true = norm(ms, axis=2)
    norm_pred = norm(ps, axis=2)

    res = np.arccos(dot_sum/norm_pred/norm_true)
    is_nan = np.nonzero(np.isnan(res))
    for (x,y) in zip(is_nan[0], is_nan[1]):
        res[x,y]=0

    sam = np.mean(res)
    return sam

def sCC(ms, ps):
    ps_sobel = sobel(ps, mode='constant')
    ms_sobel = sobel(ms, mode='constant')

    return  (np.sum(ps_sobel*ms_sobel)/np.sqrt(np.sum(ps_sobel*ps_sobel))/np.sqrt(np.sum(ms_sobel*ms_sobel)))

def CC(ms, ps):

    return  (np.sum(ps*ms)/np.sqrt(np.sum(ps*ps))/np.sqrt(np.sum(ms*ms)))

'''
#this is modified from matlab code. Don't use it. use original code.
def ERGAS(ms,ps,ratio=4.0):
    #I1:ms 融合后多光谱图像
    #I2:ps 原始图像
    #ratio: 全色图像与多光谱图像尺寸的比值
    ms = ms.double()
    ps = ps.double

    err = ms - ps
    ERGAS_index = 0
    for i in range(err.shape[2]):
        ERGAS_index=ERGAS_index+np.mean(np.power(err[:,:,i],2))/np.power(np.mean(ps[:,:,i]))


    ERGAS_index = (100 * ratio) * np.sqrt((1 / err.shape[2]) * ERGAS_index)
    return ERGAS_index
'''