import torch
import torch.nn as nn
import math
from models.blocks import Dense_Block,DenseBlock,Residual_Block

class LiMaNet(nn.Module):
    def __init__(self):
        super(LiMaNet,self).__init__()
        self.encoder_pan = nn.Sequential(
            nn.Conv2d(in_channels=1, out_channels=64, kernel_size=3, stride=1, padding=1),
            nn.PReLU(),
            nn.Conv2d(in_channels=64, out_channels=64, kernel_size=3, stride=1, padding=1),
            nn.PReLU()
        )

        self.encoder_mul = nn.Sequential(
            nn.Conv2d(in_channels=4, out_channels=64, kernel_size=3, stride=1, padding=1),
            nn.PReLU(),
            nn.Conv2d(in_channels=64, out_channels=64, kernel_size=3, stride=1, padding=1),
            nn.PReLU()
        )

        dense_blocks=[]
        for i in range(3):
            dense_blocks.append(Dense_Block())
        self.dense_blocks=nn.Sequential(*dense_blocks)

        self.decoder=nn.Sequential(
            nn.Conv2d(in_channels=256, out_channels=64, kernel_size=1, stride=1),
            nn.PReLU(),
            nn.Conv2d(in_channels=64,out_channels=64,kernel_size=3,stride=1,padding=1),
            nn.PReLU(),
            nn.Conv2d(in_channels=64,out_channels=4,kernel_size=3,stride=1,padding=1)
        )
        for m in self.modules():
            if isinstance(m, nn.Conv2d):
                n = m.kernel_size[0] * m.kernel_size[1] * m.out_channels
                m.weight.data.normal_(0, math.sqrt(2. / n))
                if m.bias is not None:
                    m.bias.data.zero_()
            elif isinstance(m, nn.BatchNorm2d):
                m.weight.data.fill_(1)
                if m.bias is not None:
                    m.bias.data.zero_()


    def forward(self, x_pan, x_mul):
        identity = x_mul
        encoder_pan = self.encoder_pan(x_pan)
        encoder_mul = self.encoder_mul(x_mul)
        fusion = self.dense_blocks(torch.cat((encoder_pan, encoder_mul), dim=1))
        restore = self.decoder(torch.cat((fusion, encoder_pan, encoder_mul), dim=1))
        return restore

class LiMaNet_IKONOS(nn.Module):
    def __init__(self):
        super(LiMaNet_IKONOS,self).__init__()
        self.encoder_pan = nn.Sequential(
            nn.Conv2d(in_channels=1, out_channels=64, kernel_size=3, stride=1, padding=1),
            nn.PReLU(),
            nn.Conv2d(in_channels=64, out_channels=64, kernel_size=3, stride=1, padding=1),
            nn.PReLU()
        )

        self.encoder_mul = nn.Sequential(
            nn.Conv2d(in_channels=4, out_channels=64, kernel_size=3, stride=1, padding=1),
            nn.PReLU(),
            nn.Conv2d(in_channels=64, out_channels=64, kernel_size=3, stride=1, padding=1),
            nn.PReLU()
        )

        dense_blocks=[]
        for i in range(3):
            dense_blocks.append(Dense_Block())
        self.dense_blocks=nn.Sequential(*dense_blocks)

        self.decoder=nn.Sequential(
            nn.Conv2d(in_channels=256, out_channels=64, kernel_size=1, stride=1),
            nn.PReLU(),
            nn.Conv2d(in_channels=64,out_channels=64,kernel_size=3,stride=1,padding=1),
            nn.PReLU(),
            nn.Conv2d(in_channels=64,out_channels=4,kernel_size=3,stride=1,padding=1)
        )
        for m in self.modules():
            if isinstance(m, nn.Conv2d):
                n = m.kernel_size[0] * m.kernel_size[1] * m.out_channels
                m.weight.data.normal_(0, math.sqrt(2. / n))
                if m.bias is not None:
                    m.bias.data.zero_()
            elif isinstance(m, nn.BatchNorm2d):
                m.weight.data.fill_(1)
                if m.bias is not None:
                    m.bias.data.zero_()


    def forward(self, x_pan, x_mul):
        identity = x_mul
        encoder_pan = self.encoder_pan(x_pan)
        encoder_mul = self.encoder_mul(x_mul)
        fusion = self.dense_blocks(torch.cat((encoder_pan, encoder_mul), dim=1))
        restore = self.decoder(torch.cat((fusion, encoder_pan, encoder_mul), dim=1))
        return restore

class LiMaNet_GaoFen2(nn.Module):
    def __init__(self):
        super(LiMaNet_GaoFen2,self).__init__()
        self.encoder_pan = nn.Sequential(
            nn.Conv2d(in_channels=1, out_channels=64, kernel_size=3, stride=1, padding=1),
            nn.PReLU(),
            nn.Conv2d(in_channels=64, out_channels=64, kernel_size=3, stride=1, padding=1),
            nn.PReLU()
        )

        self.encoder_mul = nn.Sequential(
            nn.Conv2d(in_channels=4, out_channels=64, kernel_size=3, stride=1, padding=1),
            nn.PReLU(),
            nn.Conv2d(in_channels=64, out_channels=64, kernel_size=3, stride=1, padding=1),
            nn.PReLU()
        )

        dense_blocks=[]
        for _ in range(3):
            dense_blocks.append(Dense_Block())
        self.dense_blocks=nn.Sequential(*dense_blocks)

        self.decoder=nn.Sequential(
            nn.Conv2d(in_channels=256, out_channels=64, kernel_size=1, stride=1),
            nn.PReLU(),
            nn.Conv2d(in_channels=64,out_channels=64,kernel_size=3,stride=1,padding=1),
            nn.PReLU(),
            nn.Conv2d(in_channels=64,out_channels=4,kernel_size=3,stride=1,padding=1)
        )
        for m in self.modules():
            if isinstance(m, nn.Conv2d):
                n = m.kernel_size[0] * m.kernel_size[1] * m.out_channels
                m.weight.data.normal_(0, math.sqrt(2. / n))
                if m.bias is not None:
                    m.bias.data.zero_()
            elif isinstance(m, nn.BatchNorm2d):
                m.weight.data.fill_(1)
                if m.bias is not None:
                    m.bias.data.zero_()


    def forward(self, x_pan, x_mul):
        identity = x_mul
        encoder_pan = self.encoder_pan(x_pan)
        encoder_mul = self.encoder_mul(x_mul)
        fusion = self.dense_blocks(torch.cat((encoder_pan, encoder_mul), dim=1))
        restore = self.decoder(torch.cat((fusion, encoder_pan, encoder_mul), dim=1))
        return restore

class LiMaNet_WorldView2(nn.Module):
    def __init__(self):
        super(LiMaNet_WorldView2,self).__init__()
        self.encoder_pan = nn.Sequential(
            nn.Conv2d(in_channels=1, out_channels=64, kernel_size=3, stride=1, padding=1),
            nn.PReLU(),
            nn.Conv2d(in_channels=64, out_channels=64, kernel_size=3, stride=1, padding=1),
            nn.PReLU()
        )

        self.encoder_mul = nn.Sequential(
            nn.Conv2d(in_channels=8, out_channels=64, kernel_size=3, stride=1, padding=1),
            nn.PReLU(),
            nn.Conv2d(in_channels=64, out_channels=64, kernel_size=3, stride=1, padding=1),
            nn.PReLU()
        )

        dense_blocks=[]
        for i in range(3):
            dense_blocks.append(Dense_Block())
        self.dense_blocks=nn.Sequential(*dense_blocks)

        self.decoder=nn.Sequential(
            nn.Conv2d(in_channels=256, out_channels=64, kernel_size=1, stride=1),
            nn.PReLU(),
            nn.Conv2d(in_channels=64,out_channels=64,kernel_size=3,stride=1,padding=1),
            nn.PReLU(),
            nn.Conv2d(in_channels=64,out_channels=8,kernel_size=3,stride=1,padding=1)
        )
        for m in self.modules():
            if isinstance(m, nn.Conv2d):
                n = m.kernel_size[0] * m.kernel_size[1] * m.out_channels
                m.weight.data.normal_(0, math.sqrt(2. / n))
                if m.bias is not None:
                    m.bias.data.zero_()
            elif isinstance(m, nn.BatchNorm2d):
                m.weight.data.fill_(1)
                if m.bias is not None:
                    m.bias.data.zero_()


    def forward(self, x_pan, x_mul):
        identity = x_mul
        encoder_pan = self.encoder_pan(x_pan)
        encoder_mul = self.encoder_mul(x_mul)
        fusion = self.dense_blocks(torch.cat((encoder_pan, encoder_mul), dim=1))
        restore = self.decoder(torch.cat((fusion, encoder_pan, encoder_mul), dim=1))
        return restore


class LiMaNet_IKONOS_NO_SKIP(nn.Module):
    def __init__(self):
        super(LiMaNet_IKONOS_NO_SKIP,self).__init__()
        self.encoder_pan = nn.Sequential(
            nn.Conv2d(in_channels=1, out_channels=64, kernel_size=3, stride=1, padding=1),
            nn.PReLU(),
            nn.Conv2d(in_channels=64, out_channels=64, kernel_size=3, stride=1, padding=1),
            nn.PReLU()
        )

        self.encoder_mul = nn.Sequential(
            nn.Conv2d(in_channels=4, out_channels=64, kernel_size=3, stride=1, padding=1),
            nn.PReLU(),
            nn.Conv2d(in_channels=64, out_channels=64, kernel_size=3, stride=1, padding=1),
            nn.PReLU()
        )

        dense_blocks=[]
        for i in range(3):
            dense_blocks.append(Dense_Block())
        self.dense_blocks=nn.Sequential(*dense_blocks)

        self.decoder=nn.Sequential(
            nn.ConvTranspose2d(in_channels=128, out_channels=64, kernel_size=1, stride=1),
            nn.PReLU(),
            nn.ConvTranspose2d(in_channels=64,out_channels=64,kernel_size=3,stride=1,padding=1),
            nn.PReLU(),
            nn.ConvTranspose2d(in_channels=64,out_channels=4,kernel_size=3,stride=1,padding=1)
        )
        for m in self.modules():
            if isinstance(m, nn.Conv2d):
                n = m.kernel_size[0] * m.kernel_size[1] * m.out_channels
                m.weight.data.normal_(0, math.sqrt(2. / n))
                if m.bias is not None:
                    m.bias.data.zero_()
            elif isinstance(m, nn.BatchNorm2d):
                m.weight.data.fill_(1)
                if m.bias is not None:
                    m.bias.data.zero_()


    def forward(self, x_pan, x_mul):
        identity = x_mul
        encoder_pan = self.encoder_pan(x_pan)
        encoder_mul = self.encoder_mul(x_mul)
        fusion = self.dense_blocks(torch.cat((encoder_pan, encoder_mul), dim=1))
        restore = self.decoder(fusion)
        return restore

class LiMaNet_GaoFen2_NO_SKIP(nn.Module):
    def __init__(self):
        super(LiMaNet_GaoFen2_NO_SKIP,self).__init__()
        self.encoder_pan = nn.Sequential(
            nn.Conv2d(in_channels=1, out_channels=64, kernel_size=3, stride=1, padding=1),
            nn.PReLU(),
            nn.Conv2d(in_channels=64, out_channels=64, kernel_size=3, stride=1, padding=1),
            nn.PReLU()
        )

        self.encoder_mul = nn.Sequential(
            nn.Conv2d(in_channels=4, out_channels=64, kernel_size=3, stride=1, padding=1),
            nn.PReLU(),
            nn.Conv2d(in_channels=64, out_channels=64, kernel_size=3, stride=1, padding=1),
            nn.PReLU()
        )

        dense_blocks=[]
        for _ in range(3):
            dense_blocks.append(Dense_Block())
        self.dense_blocks=nn.Sequential(*dense_blocks)

        self.decoder=nn.Sequential(
            nn.ConvTranspose2d(in_channels=128, out_channels=64, kernel_size=1, stride=1),
            nn.PReLU(),
            nn.ConvTranspose2d(in_channels=64,out_channels=64,kernel_size=3,stride=1,padding=1),
            nn.PReLU(),
            nn.ConvTranspose2d(in_channels=64,out_channels=4,kernel_size=3,stride=1,padding=1)
        )
        for m in self.modules():
            if isinstance(m, nn.Conv2d):
                n = m.kernel_size[0] * m.kernel_size[1] * m.out_channels
                m.weight.data.normal_(0, math.sqrt(2. / n))
                if m.bias is not None:
                    m.bias.data.zero_()
            elif isinstance(m, nn.BatchNorm2d):
                m.weight.data.fill_(1)
                if m.bias is not None:
                    m.bias.data.zero_()


    def forward(self, x_pan, x_mul):
        identity = x_mul
        encoder_pan = self.encoder_pan(x_pan)
        encoder_mul = self.encoder_mul(x_mul)
        fusion = self.dense_blocks(torch.cat((encoder_pan, encoder_mul), dim=1))
        restore = self.decoder(fusion)
        return restore

class LiMaNet_WorldView2_NO_SKIP(nn.Module):
    def __init__(self):
        super(LiMaNet_WorldView2_NO_SKIP,self).__init__()
        self.encoder_pan = nn.Sequential(
            nn.Conv2d(in_channels=1, out_channels=64, kernel_size=3, stride=1, padding=1),
            nn.PReLU(),
            nn.Conv2d(in_channels=64, out_channels=64, kernel_size=3, stride=1, padding=1),
            nn.PReLU()
        )

        self.encoder_mul = nn.Sequential(
            nn.Conv2d(in_channels=8, out_channels=64, kernel_size=3, stride=1, padding=1),
            nn.PReLU(),
            nn.Conv2d(in_channels=64, out_channels=64, kernel_size=3, stride=1, padding=1),
            nn.PReLU()
        )

        dense_blocks=[]
        for i in range(3):
            dense_blocks.append(Dense_Block())
        self.dense_blocks=nn.Sequential(*dense_blocks)

        self.decoder=nn.Sequential(
            nn.ConvTranspose2d(in_channels=128, out_channels=64, kernel_size=1, stride=1),
            nn.PReLU(),
            nn.ConvTranspose2d(in_channels=64,out_channels=64,kernel_size=3,stride=1,padding=1),
            nn.PReLU(),
            nn.ConvTranspose2d(in_channels=64,out_channels=8,kernel_size=3,stride=1,padding=1)
        )
        for m in self.modules():
            if isinstance(m, nn.Conv2d):
                n = m.kernel_size[0] * m.kernel_size[1] * m.out_channels
                m.weight.data.normal_(0, math.sqrt(2. / n))
                if m.bias is not None:
                    m.bias.data.zero_()
            elif isinstance(m, nn.BatchNorm2d):
                m.weight.data.fill_(1)
                if m.bias is not None:
                    m.bias.data.zero_()


    def forward(self, x_pan, x_mul):
        identity = x_mul
        encoder_pan = self.encoder_pan(x_pan)
        encoder_mul = self.encoder_mul(x_mul)
        fusion = self.dense_blocks(torch.cat((encoder_pan, encoder_mul), dim=1))
        restore = self.decoder(fusion)
        return restore


class LiMaNet_IKONOS_RES_SKIP(nn.Module):
    def __init__(self):
        super(LiMaNet_IKONOS_RES_SKIP,self).__init__()
        self.encoder_pan = nn.Sequential(
            nn.Conv2d(in_channels=1, out_channels=64, kernel_size=3, stride=1, padding=1),
            nn.PReLU(),
            nn.Conv2d(in_channels=64, out_channels=64, kernel_size=3, stride=1, padding=1),
            nn.PReLU()
        )

        self.encoder_mul = nn.Sequential(
            nn.Conv2d(in_channels=4, out_channels=64, kernel_size=3, stride=1, padding=1),
            nn.PReLU(),
            nn.Conv2d(in_channels=64, out_channels=64, kernel_size=3, stride=1, padding=1),
            nn.PReLU()
        )

        dense_blocks=[]
        for i in range(3):
            dense_blocks.append(Dense_Block())
        self.dense_blocks=nn.Sequential(*dense_blocks)

        self.decoder=nn.Sequential(
            nn.Conv2d(in_channels=256, out_channels=64, kernel_size=1, stride=1),
            nn.PReLU(),
            nn.Conv2d(in_channels=64,out_channels=64,kernel_size=3,stride=1,padding=1),
            nn.PReLU(),
            nn.Conv2d(in_channels=64,out_channels=4,kernel_size=3,stride=1,padding=1)
        )
        for m in self.modules():
            if isinstance(m, nn.Conv2d):
                n = m.kernel_size[0] * m.kernel_size[1] * m.out_channels
                m.weight.data.normal_(0, math.sqrt(2. / n))
                if m.bias is not None:
                    m.bias.data.zero_()
            elif isinstance(m, nn.BatchNorm2d):
                m.weight.data.fill_(1)
                if m.bias is not None:
                    m.bias.data.zero_()


    def forward(self, x_pan, x_mul):
        identity = x_mul
        encoder_pan = self.encoder_pan(x_pan)
        encoder_mul = self.encoder_mul(x_mul)
        fusion = self.dense_blocks(torch.cat((encoder_pan, encoder_mul), dim=1))
        restore = self.decoder(torch.cat((fusion, encoder_pan, encoder_mul), dim=1))+identity
        return restore

class LiMaNet_GaoFen2_RES_SKIP(nn.Module):
    def __init__(self):
        super(LiMaNet_GaoFen2_RES_SKIP,self).__init__()
        self.encoder_pan = nn.Sequential(
            nn.Conv2d(in_channels=1, out_channels=64, kernel_size=3, stride=1, padding=1),
            nn.PReLU(),
            nn.Conv2d(in_channels=64, out_channels=64, kernel_size=3, stride=1, padding=1),
            nn.PReLU()
        )

        self.encoder_mul = nn.Sequential(
            nn.Conv2d(in_channels=4, out_channels=64, kernel_size=3, stride=1, padding=1),
            nn.PReLU(),
            nn.Conv2d(in_channels=64, out_channels=64, kernel_size=3, stride=1, padding=1),
            nn.PReLU()
        )

        dense_blocks=[]
        for _ in range(3):
            dense_blocks.append(Dense_Block())
        self.dense_blocks=nn.Sequential(*dense_blocks)

        self.decoder=nn.Sequential(
            nn.Conv2d(in_channels=256, out_channels=64, kernel_size=1, stride=1),
            nn.PReLU(),
            nn.Conv2d(in_channels=64,out_channels=64,kernel_size=3,stride=1,padding=1),
            nn.PReLU(),
            nn.Conv2d(in_channels=64,out_channels=4,kernel_size=3,stride=1,padding=1)
        )
        for m in self.modules():
            if isinstance(m, nn.Conv2d):
                n = m.kernel_size[0] * m.kernel_size[1] * m.out_channels
                m.weight.data.normal_(0, math.sqrt(2. / n))
                if m.bias is not None:
                    m.bias.data.zero_()
            elif isinstance(m, nn.BatchNorm2d):
                m.weight.data.fill_(1)
                if m.bias is not None:
                    m.bias.data.zero_()


    def forward(self, x_pan, x_mul):
        identity = x_mul
        encoder_pan = self.encoder_pan(x_pan)
        encoder_mul = self.encoder_mul(x_mul)
        fusion = self.dense_blocks(torch.cat((encoder_pan, encoder_mul), dim=1))
        restore = self.decoder(torch.cat((fusion, encoder_pan, encoder_mul), dim=1))+identity
        return restore

class LiMaNet_WorldView2_RES_SKIP(nn.Module):
    def __init__(self):
        super(LiMaNet_WorldView2_RES_SKIP,self).__init__()
        self.encoder_pan = nn.Sequential(
            nn.Conv2d(in_channels=1, out_channels=64, kernel_size=3, stride=1, padding=1),
            nn.PReLU(),
            nn.Conv2d(in_channels=64, out_channels=64, kernel_size=3, stride=1, padding=1),
            nn.PReLU()
        )

        self.encoder_mul = nn.Sequential(
            nn.Conv2d(in_channels=8, out_channels=64, kernel_size=3, stride=1, padding=1),
            nn.PReLU(),
            nn.Conv2d(in_channels=64, out_channels=64, kernel_size=3, stride=1, padding=1),
            nn.PReLU()
        )

        dense_blocks=[]
        for i in range(3):
            dense_blocks.append(Dense_Block())
        self.dense_blocks=nn.Sequential(*dense_blocks)

        self.decoder=nn.Sequential(
            nn.Conv2d(in_channels=256, out_channels=64, kernel_size=1, stride=1),
            nn.PReLU(),
            nn.Conv2d(in_channels=64,out_channels=64,kernel_size=3,stride=1,padding=1),
            nn.PReLU(),
            nn.Conv2d(in_channels=64,out_channels=8,kernel_size=3,stride=1,padding=1)
        )
        for m in self.modules():
            if isinstance(m, nn.Conv2d):
                n = m.kernel_size[0] * m.kernel_size[1] * m.out_channels
                m.weight.data.normal_(0, math.sqrt(2. / n))
                if m.bias is not None:
                    m.bias.data.zero_()
            elif isinstance(m, nn.BatchNorm2d):
                m.weight.data.fill_(1)
                if m.bias is not None:
                    m.bias.data.zero_()


    def forward(self, x_pan, x_mul):
        identity = x_mul
        encoder_pan = self.encoder_pan(x_pan)
        encoder_mul = self.encoder_mul(x_mul)
        fusion = self.dense_blocks(torch.cat((encoder_pan, encoder_mul), dim=1))
        restore = self.decoder(torch.cat((fusion, encoder_pan, encoder_mul), dim=1))+identity
        return restore


class LiMaNet_RES_block_IKONOS(nn.Module):
    def __init__(self):
        super(LiMaNet_RES_block_IKONOS,self).__init__()
        self.encoder_pan = nn.Sequential(
            nn.Conv2d(in_channels=1, out_channels=64, kernel_size=3, stride=1, padding=1),
            nn.PReLU(),
            nn.Conv2d(in_channels=64, out_channels=64, kernel_size=3, stride=1, padding=1),
            nn.PReLU()
        )

        self.encoder_mul = nn.Sequential(
            nn.Conv2d(in_channels=4, out_channels=64, kernel_size=3, stride=1, padding=1),
            nn.PReLU(),
            nn.Conv2d(in_channels=64, out_channels=64, kernel_size=3, stride=1, padding=1),
            nn.PReLU()
        )

        dense_blocks=[]
        for i in range(9):
            dense_blocks.append(Residual_Block(128))
        self.dense_blocks=nn.Sequential(*dense_blocks)

        self.decoder=nn.Sequential(
            nn.Conv2d(in_channels=256, out_channels=64, kernel_size=1, stride=1),
            nn.PReLU(),
            nn.Conv2d(in_channels=64,out_channels=64,kernel_size=3,stride=1,padding=1),
            nn.PReLU(),
            nn.Conv2d(in_channels=64,out_channels=4,kernel_size=3,stride=1,padding=1)
        )
        for m in self.modules():
            if isinstance(m, nn.Conv2d):
                n = m.kernel_size[0] * m.kernel_size[1] * m.out_channels
                m.weight.data.normal_(0, math.sqrt(2. / n))
                if m.bias is not None:
                    m.bias.data.zero_()
            elif isinstance(m, nn.BatchNorm2d):
                m.weight.data.fill_(1)
                if m.bias is not None:
                    m.bias.data.zero_()


    def forward(self, x_pan, x_mul):
        identity = x_mul
        encoder_pan = self.encoder_pan(x_pan)
        encoder_mul = self.encoder_mul(x_mul)
        fusion = self.dense_blocks(torch.cat((encoder_pan, encoder_mul), dim=1))
        restore = self.decoder(torch.cat((fusion, encoder_pan, encoder_mul), dim=1))
        return restore

class LiMaNet_RES_block_GaoFen2(nn.Module):
    def __init__(self):
        super(LiMaNet_RES_block_GaoFen2,self).__init__()
        self.encoder_pan = nn.Sequential(
            nn.Conv2d(in_channels=1, out_channels=64, kernel_size=3, stride=1, padding=1),
            nn.PReLU(),
            nn.Conv2d(in_channels=64, out_channels=64, kernel_size=3, stride=1, padding=1),
            nn.PReLU()
        )

        self.encoder_mul = nn.Sequential(
            nn.Conv2d(in_channels=4, out_channels=64, kernel_size=3, stride=1, padding=1),
            nn.PReLU(),
            nn.Conv2d(in_channels=64, out_channels=64, kernel_size=3, stride=1, padding=1),
            nn.PReLU()
        )

        dense_blocks=[]
        for i in range(9):
            dense_blocks.append(Residual_Block(128))
        self.dense_blocks=nn.Sequential(*dense_blocks)

        self.decoder=nn.Sequential(
            nn.Conv2d(in_channels=256, out_channels=64, kernel_size=1, stride=1),
            nn.PReLU(),
            nn.Conv2d(in_channels=64,out_channels=64,kernel_size=3,stride=1,padding=1),
            nn.PReLU(),
            nn.Conv2d(in_channels=64,out_channels=4,kernel_size=3,stride=1,padding=1)
        )
        for m in self.modules():
            if isinstance(m, nn.Conv2d):
                n = m.kernel_size[0] * m.kernel_size[1] * m.out_channels
                m.weight.data.normal_(0, math.sqrt(2. / n))
                if m.bias is not None:
                    m.bias.data.zero_()
            elif isinstance(m, nn.BatchNorm2d):
                m.weight.data.fill_(1)
                if m.bias is not None:
                    m.bias.data.zero_()


    def forward(self, x_pan, x_mul):
        identity = x_mul
        encoder_pan = self.encoder_pan(x_pan)
        encoder_mul = self.encoder_mul(x_mul)
        fusion = self.dense_blocks(torch.cat((encoder_pan, encoder_mul), dim=1))
        restore = self.decoder(torch.cat((fusion, encoder_pan, encoder_mul), dim=1))
        return restore

class LiMaNet_RES_block_WorldView2(nn.Module):
    def __init__(self):
        super(LiMaNet_RES_block_WorldView2,self).__init__()
        self.encoder_pan = nn.Sequential(
            nn.Conv2d(in_channels=1, out_channels=64, kernel_size=3, stride=1, padding=1),
            nn.PReLU(),
            nn.Conv2d(in_channels=64, out_channels=64, kernel_size=3, stride=1, padding=1),
            nn.PReLU()
        )

        self.encoder_mul = nn.Sequential(
            nn.Conv2d(in_channels=8, out_channels=64, kernel_size=3, stride=1, padding=1),
            nn.PReLU(),
            nn.Conv2d(in_channels=64, out_channels=64, kernel_size=3, stride=1, padding=1),
            nn.PReLU()
        )

        dense_blocks=[]
        for i in range(9):
            dense_blocks.append(Residual_Block(128))
        self.dense_blocks=nn.Sequential(*dense_blocks)

        self.decoder=nn.Sequential(
            nn.Conv2d(in_channels=256, out_channels=64, kernel_size=1, stride=1),
            nn.PReLU(),
            nn.Conv2d(in_channels=64,out_channels=64,kernel_size=3,stride=1,padding=1),
            nn.PReLU(),
            nn.Conv2d(in_channels=64,out_channels=8,kernel_size=3,stride=1,padding=1)
        )
        for m in self.modules():
            if isinstance(m, nn.Conv2d):
                n = m.kernel_size[0] * m.kernel_size[1] * m.out_channels
                m.weight.data.normal_(0, math.sqrt(2. / n))
                if m.bias is not None:
                    m.bias.data.zero_()
            elif isinstance(m, nn.BatchNorm2d):
                m.weight.data.fill_(1)
                if m.bias is not None:
                    m.bias.data.zero_()


    def forward(self, x_pan, x_mul):
        identity = x_mul
        encoder_pan = self.encoder_pan(x_pan)
        encoder_mul = self.encoder_mul(x_mul)
        fusion = self.dense_blocks(torch.cat((encoder_pan, encoder_mul), dim=1))
        restore = self.decoder(torch.cat((fusion, encoder_pan, encoder_mul), dim=1))
        return restore


class LiMaNet_RES_block_IKONOS_NO_SKIP(nn.Module):
    def __init__(self):
        super(LiMaNet_RES_block_IKONOS_NO_SKIP,self).__init__()
        self.encoder_pan = nn.Sequential(
            nn.Conv2d(in_channels=1, out_channels=64, kernel_size=3, stride=1, padding=1),
            nn.PReLU(),
            nn.Conv2d(in_channels=64, out_channels=64, kernel_size=3, stride=1, padding=1),
            nn.PReLU()
        )

        self.encoder_mul = nn.Sequential(
            nn.Conv2d(in_channels=4, out_channels=64, kernel_size=3, stride=1, padding=1),
            nn.PReLU(),
            nn.Conv2d(in_channels=64, out_channels=64, kernel_size=3, stride=1, padding=1),
            nn.PReLU()
        )

        dense_blocks=[]
        for i in range(9):
            dense_blocks.append(Residual_Block(128))
        self.dense_blocks=nn.Sequential(*dense_blocks)

        self.decoder=nn.Sequential(
            nn.ConvTranspose2d(in_channels=128, out_channels=64, kernel_size=1, stride=1),
            nn.PReLU(),
            nn.ConvTranspose2d(in_channels=64,out_channels=64,kernel_size=3,stride=1,padding=1),
            nn.PReLU(),
            nn.ConvTranspose2d(in_channels=64,out_channels=4,kernel_size=3,stride=1,padding=1)
        )
        for m in self.modules():
            if isinstance(m, nn.Conv2d):
                n = m.kernel_size[0] * m.kernel_size[1] * m.out_channels
                m.weight.data.normal_(0, math.sqrt(2. / n))
                if m.bias is not None:
                    m.bias.data.zero_()
            elif isinstance(m, nn.BatchNorm2d):
                m.weight.data.fill_(1)
                if m.bias is not None:
                    m.bias.data.zero_()


    def forward(self, x_pan, x_mul):
        identity = x_mul
        encoder_pan = self.encoder_pan(x_pan)
        encoder_mul = self.encoder_mul(x_mul)
        fusion = self.dense_blocks(torch.cat((encoder_pan, encoder_mul), dim=1))
        restore = self.decoder(fusion)
        return restore

class LiMaNet_RES_block_GaoFen2_NO_SKIP(nn.Module):
    def __init__(self):
        super(LiMaNet_RES_block_GaoFen2_NO_SKIP,self).__init__()
        self.encoder_pan = nn.Sequential(
            nn.Conv2d(in_channels=1, out_channels=64, kernel_size=3, stride=1, padding=1),
            nn.PReLU(),
            nn.Conv2d(in_channels=64, out_channels=64, kernel_size=3, stride=1, padding=1),
            nn.PReLU()
        )

        self.encoder_mul = nn.Sequential(
            nn.Conv2d(in_channels=4, out_channels=64, kernel_size=3, stride=1, padding=1),
            nn.PReLU(),
            nn.Conv2d(in_channels=64, out_channels=64, kernel_size=3, stride=1, padding=1),
            nn.PReLU()
        )

        dense_blocks=[]
        for i in range(9):
            dense_blocks.append(Residual_Block(128))
        self.dense_blocks=nn.Sequential(*dense_blocks)

        self.decoder=nn.Sequential(
            nn.ConvTranspose2d(in_channels=128, out_channels=64, kernel_size=1, stride=1),
            nn.PReLU(),
            nn.ConvTranspose2d(in_channels=64,out_channels=64,kernel_size=3,stride=1,padding=1),
            nn.PReLU(),
            nn.ConvTranspose2d(in_channels=64,out_channels=4,kernel_size=3,stride=1,padding=1)
        )
        for m in self.modules():
            if isinstance(m, nn.Conv2d):
                n = m.kernel_size[0] * m.kernel_size[1] * m.out_channels
                m.weight.data.normal_(0, math.sqrt(2. / n))
                if m.bias is not None:
                    m.bias.data.zero_()
            elif isinstance(m, nn.BatchNorm2d):
                m.weight.data.fill_(1)
                if m.bias is not None:
                    m.bias.data.zero_()


    def forward(self, x_pan, x_mul):
        identity = x_mul
        encoder_pan = self.encoder_pan(x_pan)
        encoder_mul = self.encoder_mul(x_mul)
        fusion = self.dense_blocks(torch.cat((encoder_pan, encoder_mul), dim=1))
        restore = self.decoder(fusion)
        return restore

class LiMaNet_RES_block_WorldView2_NO_SKIP(nn.Module):
    def __init__(self):
        super(LiMaNet_RES_block_WorldView2_NO_SKIP,self).__init__()
        self.encoder_pan = nn.Sequential(
            nn.Conv2d(in_channels=1, out_channels=64, kernel_size=3, stride=1, padding=1),
            nn.PReLU(),
            nn.Conv2d(in_channels=64, out_channels=64, kernel_size=3, stride=1, padding=1),
            nn.PReLU()
        )

        self.encoder_mul = nn.Sequential(
            nn.Conv2d(in_channels=8, out_channels=64, kernel_size=3, stride=1, padding=1),
            nn.PReLU(),
            nn.Conv2d(in_channels=64, out_channels=64, kernel_size=3, stride=1, padding=1),
            nn.PReLU()
        )

        dense_blocks=[]
        for i in range(9):
            dense_blocks.append(Residual_Block(128))
        self.dense_blocks=nn.Sequential(*dense_blocks)

        self.decoder=nn.Sequential(
            nn.ConvTranspose2d(in_channels=128, out_channels=64, kernel_size=1, stride=1),
            nn.PReLU(),
            nn.ConvTranspose2d(in_channels=64,out_channels=64,kernel_size=3,stride=1,padding=1),
            nn.PReLU(),
            nn.ConvTranspose2d(in_channels=64,out_channels=8,kernel_size=3,stride=1,padding=1)
        )
        for m in self.modules():
            if isinstance(m, nn.Conv2d):
                n = m.kernel_size[0] * m.kernel_size[1] * m.out_channels
                m.weight.data.normal_(0, math.sqrt(2. / n))
                if m.bias is not None:
                    m.bias.data.zero_()
            elif isinstance(m, nn.BatchNorm2d):
                m.weight.data.fill_(1)
                if m.bias is not None:
                    m.bias.data.zero_()


    def forward(self, x_pan, x_mul):
        identity = x_mul
        encoder_pan = self.encoder_pan(x_pan)
        encoder_mul = self.encoder_mul(x_mul)
        fusion = self.dense_blocks(torch.cat((encoder_pan, encoder_mul), dim=1))
        restore = self.decoder(fusion)
        return restore



class LiMaNet_RES_block_IKONOS_RES_SKIP(nn.Module):
    def __init__(self):
        super(LiMaNet_RES_block_IKONOS_RES_SKIP,self).__init__()
        self.encoder_pan = nn.Sequential(
            nn.Conv2d(in_channels=1, out_channels=64, kernel_size=3, stride=1, padding=1),
            nn.PReLU(),
            nn.Conv2d(in_channels=64, out_channels=64, kernel_size=3, stride=1, padding=1),
            nn.PReLU()
        )

        self.encoder_mul = nn.Sequential(
            nn.Conv2d(in_channels=4, out_channels=64, kernel_size=3, stride=1, padding=1),
            nn.PReLU(),
            nn.Conv2d(in_channels=64, out_channels=64, kernel_size=3, stride=1, padding=1),
            nn.PReLU()
        )

        dense_blocks=[]
        for i in range(9):
            dense_blocks.append(Residual_Block(128))
        self.dense_blocks=nn.Sequential(*dense_blocks)

        self.decoder=nn.Sequential(
            nn.Conv2d(in_channels=256, out_channels=64, kernel_size=1, stride=1),
            nn.PReLU(),
            nn.Conv2d(in_channels=64,out_channels=64,kernel_size=3,stride=1,padding=1),
            nn.PReLU(),
            nn.Conv2d(in_channels=64,out_channels=4,kernel_size=3,stride=1,padding=1)
        )
        for m in self.modules():
            if isinstance(m, nn.Conv2d):
                n = m.kernel_size[0] * m.kernel_size[1] * m.out_channels
                m.weight.data.normal_(0, math.sqrt(2. / n))
                if m.bias is not None:
                    m.bias.data.zero_()
            elif isinstance(m, nn.BatchNorm2d):
                m.weight.data.fill_(1)
                if m.bias is not None:
                    m.bias.data.zero_()


    def forward(self, x_pan, x_mul):
        identity = x_mul
        encoder_pan = self.encoder_pan(x_pan)
        encoder_mul = self.encoder_mul(x_mul)
        fusion = self.dense_blocks(torch.cat((encoder_pan, encoder_mul), dim=1))
        restore = self.decoder(torch.cat((fusion, encoder_pan, encoder_mul), dim=1))+identity
        return restore

class LiMaNet_RES_block_GaoFen2_RES_SKIP(nn.Module):
    def __init__(self):
        super(LiMaNet_RES_block_GaoFen2_RES_SKIP,self).__init__()
        self.encoder_pan = nn.Sequential(
            nn.Conv2d(in_channels=1, out_channels=64, kernel_size=3, stride=1, padding=1),
            nn.PReLU(),
            nn.Conv2d(in_channels=64, out_channels=64, kernel_size=3, stride=1, padding=1),
            nn.PReLU()
        )

        self.encoder_mul = nn.Sequential(
            nn.Conv2d(in_channels=4, out_channels=64, kernel_size=3, stride=1, padding=1),
            nn.PReLU(),
            nn.Conv2d(in_channels=64, out_channels=64, kernel_size=3, stride=1, padding=1),
            nn.PReLU()
        )

        dense_blocks=[]
        for i in range(9):
            dense_blocks.append(Residual_Block(128))
        self.dense_blocks=nn.Sequential(*dense_blocks)

        self.decoder=nn.Sequential(
            nn.Conv2d(in_channels=256, out_channels=64, kernel_size=1, stride=1),
            nn.PReLU(),
            nn.Conv2d(in_channels=64,out_channels=64,kernel_size=3,stride=1,padding=1),
            nn.PReLU(),
            nn.Conv2d(in_channels=64,out_channels=4,kernel_size=3,stride=1,padding=1)
        )
        for m in self.modules():
            if isinstance(m, nn.Conv2d):
                n = m.kernel_size[0] * m.kernel_size[1] * m.out_channels
                m.weight.data.normal_(0, math.sqrt(2. / n))
                if m.bias is not None:
                    m.bias.data.zero_()
            elif isinstance(m, nn.BatchNorm2d):
                m.weight.data.fill_(1)
                if m.bias is not None:
                    m.bias.data.zero_()


    def forward(self, x_pan, x_mul):
        identity = x_mul
        encoder_pan = self.encoder_pan(x_pan)
        encoder_mul = self.encoder_mul(x_mul)
        fusion = self.dense_blocks(torch.cat((encoder_pan, encoder_mul), dim=1))
        restore = self.decoder(torch.cat((fusion, encoder_pan, encoder_mul), dim=1))+identity
        return restore

class LiMaNet_RES_block_WorldView2_RES_SKIP(nn.Module):
    def __init__(self):
        super(LiMaNet_RES_block_WorldView2_RES_SKIP,self).__init__()
        self.encoder_pan = nn.Sequential(
            nn.Conv2d(in_channels=1, out_channels=64, kernel_size=3, stride=1, padding=1),
            nn.PReLU(),
            nn.Conv2d(in_channels=64, out_channels=64, kernel_size=3, stride=1, padding=1),
            nn.PReLU()
        )

        self.encoder_mul = nn.Sequential(
            nn.Conv2d(in_channels=8, out_channels=64, kernel_size=3, stride=1, padding=1),
            nn.PReLU(),
            nn.Conv2d(in_channels=64, out_channels=64, kernel_size=3, stride=1, padding=1),
            nn.PReLU()
        )

        dense_blocks=[]
        for i in range(9):
            dense_blocks.append(Residual_Block(128))
        self.dense_blocks=nn.Sequential(*dense_blocks)

        self.decoder=nn.Sequential(
            nn.Conv2d(in_channels=256, out_channels=64, kernel_size=1, stride=1),
            nn.PReLU(),
            nn.Conv2d(in_channels=64,out_channels=64,kernel_size=3,stride=1,padding=1),
            nn.PReLU(),
            nn.Conv2d(in_channels=64,out_channels=8,kernel_size=3,stride=1,padding=1)
        )
        for m in self.modules():
            if isinstance(m, nn.Conv2d):
                n = m.kernel_size[0] * m.kernel_size[1] * m.out_channels
                m.weight.data.normal_(0, math.sqrt(2. / n))
                if m.bias is not None:
                    m.bias.data.zero_()
            elif isinstance(m, nn.BatchNorm2d):
                m.weight.data.fill_(1)
                if m.bias is not None:
                    m.bias.data.zero_()


    def forward(self, x_pan, x_mul):
        identity = x_mul
        encoder_pan = self.encoder_pan(x_pan)
        encoder_mul = self.encoder_mul(x_mul)
        fusion = self.dense_blocks(torch.cat((encoder_pan, encoder_mul), dim=1))
        restore = self.decoder(torch.cat((fusion, encoder_pan, encoder_mul), dim=1))+identity
        return restore

